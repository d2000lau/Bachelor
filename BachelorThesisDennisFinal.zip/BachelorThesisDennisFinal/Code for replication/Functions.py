import numpy as np

def lagaugment(a, p):  # this will augment a vector/matrix a, by its lags
    try:
        a = a.reshape(a.shape[0], 1)
    except ValueError or IndexError:
        pass
    if p == 0:
        return a
    else:
        b = np.zeros([a.shape[0], p * a.shape[1]])
        b.fill(np.NaN)
        for pp in range(p):
            b[pp + 1:, a.shape[1] * pp:(pp + 1) * a.shape[1]] = a[:-(pp + 1), :]
    return a, b

def dmtest(e1, e2, h):
    e1 = e1.reshape(e1.shape[0], 1)
    e2 = e2.reshape(e2.shape[0], 1)
    T = e1.shape[0]  # observations
    d = e1**2 - e2**2  # Loss differential
    Mu = np.mean(d)  # Var of Loss differential
    gamma0 = np.var(d) * T / (T - 1)  # Autocorr

    if h > 1:
        gamma = np.zeros([h - 1, 1])
        for i in range(1, h):
            sCov = np.cov(np.vstack((d[i:T].T, d[0:T - i].T)))
            gamma[i - 1] = sCov[0, 1]
        varD = gamma0 + 2 * sum(gamma)[0]
    else:
        varD = gamma0

    DM = Mu / np.sqrt((1 / T) * varD)  # DM statistic ~N(0,1)
    return DM