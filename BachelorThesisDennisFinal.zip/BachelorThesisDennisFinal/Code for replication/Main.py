'''Import packages & functions'''
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.decomposition import PCA, KernelPCA
from sklearn.preprocessing import StandardScaler
import statsmodels.api as sm
import os
import time
from numpy.random import seed
os.chdir(os.path.dirname(__file__)) # Specify the current directory
from Functions import lagaugment, dmtest

''' Read Data'''
dum = pd.read_csv('Data/2020-05.csv', header=None) 
Header = dum.values[:1, 1:]  
Data = dum.values[14:-1, 1:].astype('float64')  
rawdata = dum.values[2:-1,1:] 
Trans_code = dum.values[1,1:].reshape(-1,1) 

''' Data Transformation'''
yt = np.nan*np.empty((rawdata.shape[0],rawdata.shape[1]))
for i in range(rawdata.shape[1]):
  x = rawdata[:,i].astype(np.float)  
  tcode = Trans_code[i][0]
  n = x.shape[0]
  small = 1e-6
  if tcode == '1':                            # Level (i.e. no transformation): x(t)
    yt[:,i] = x
  elif tcode == '2':                          # First difference: x(t)-x(t-1)
    yt[1:n,i] = x[1:n]-x[0:n-1]
  elif tcode == '3':                          # Second difference: (x(t)-x(t-1))-(x(t-1)-x(t-2))
    yt[2:n,i] = x[2:n]-2*x[1:n-1] + x[0:n-2]
  elif tcode == '4' and np.nanmin(x) > small: # Natural log: ln(x)
    yt[:,i]=np.log(x)
  elif tcode == '5' and np.nanmin(x) > small: # First difference of natural log: ln(x)-ln(x-1)
    x = np.log(x)
    yt[1:n,i] = (x[1:n]-x[0:n-1])
  elif tcode == '6' and np.nanmin(x) > small: # Second difference of natural log: (ln(x)-ln(x-1))-(ln(x-1)-ln(x-2))
    x = np.log(x)
    yt[2:n,i] = x[2:n] - 2*x[1:n-1] + x[0:n-2]
  elif tcode == '7':                          # First difference of percent change: (x(t)/x(t-1)-1)-(x(t-1)/x(t-2)-1)
    z = np.zeros([n])
    z[1:n] = (x[1:n]-x[0:n-1])/x[0:n-1]
    yt[2:n,i] = z[2:n]-z[1:n-1]

np.savetxt('Data_Out/Transformed.csv', yt, delimiter=',')
Transformed = pd.read_csv('Data_Out/Transformed.csv', header=None).values  # (732,128)
Data_tra = Transformed[12:, :]  # (720,128)

''' Specification of parameters & variables'''
P = 6  # max lags of Y
M = 6  # max lags of factors
K = 6  # max factors

Series = ['RPI', 'CE16OV', 'HOUST', 'DPCERA3M086SBEA', 'M1SL', 'FEDFUNDS', 'CPIAUCSL', 'S&P 500']  # Series to predict  ['RPI', 'CE16OV', 'HOUST', 'DPCERA3M086SBEA', 'M1SL', 'FEDFUNDS', 'CPIAUCSL', 'S&P 500']
horstotal = [1, 3, 6, 9, 12, 18, 24]  # Horizons to predict
Modes = ['PCA', 'SPC','PC2','KPCApoly', 'KPCAsigmoid','KPCArbf'] # ['PCA', 'SPC','PC2','KPCApoly', 'KPCAsigmoid','KPCArbf']

indexes = [np.where(Header == i)[1][0] for i in Series]  # Series indexes

MSPEs = np.zeros([len(Series), len(horstotal)])  # 16 variables, 7 horizons

est_window = 120
OOS_obs = Data.shape[0] - est_window
TimeSeries = np.zeros([OOS_obs, 2 * len(horstotal)])  # First 7 columns are Ytrue and next 7 are Yhat (for each of 7 horizons)

DMdic = {}

''' Forecasting for each method, each series, each horizon, each time step, each hyperparameter'''
for Mode in Modes:  
  DMdic[Mode] = np.zeros([OOS_obs, len(horstotal)*len(Series)]) # This table stores prediction errors of size (OOS_obs x 1) for each variable and each horizon, this is used to calculate DM test
  if Mode[0] == 'K':
    kernel = Mode[4:]
  else:
    kernel = False
  for varnum, varind in enumerate(indexes):   
      for hornum, hor in enumerate(horstotal):  
          target = Data[:, varind]  
          W = np.delete(Data_tra, varind, 1) 

          Yg, Yd = np.zeros([target.shape[0], 1]), np.zeros([target.shape[0], 1])  
          Yg[0:hor] = None
          Yg[hor:] = ((np.log(target[hor:]) - np.log(target[:-hor])) / hor).reshape(target[hor:].shape[0], 1) # Log Diff / h
          Yd[0] = None
          Yd[1:] = (np.log(target[1:]) - np.log(target[:-1])).reshape(target[1:].shape[0], 1)                 # Log Diff

          Ytrue = Yg[est_window:]       
          Yhat = np.zeros([OOS_obs, 1]) 

          if kernel == 'sigmoid':
              grid = 10**np.arange(-6,-1.5,.5)
          elif kernel == 'rbf':
              grid = 10**np.arange(-6,-2.5,.5)
          else:
              grid = [1]
              
          for t in range(OOS_obs):
              if t < 2:
                  kill = 2 - t
              else:
                  kill = 0
              Ygt = Yg[t:est_window - hor + 1 + t]  
              Ydt = Yd[t:est_window - hor + 1 + t]  
              Wt = W[kill + t:est_window - hor + 1 + t, :]  
              Wt = Wt[:, ~np.any(np.isnan(Wt), axis=0)]  

              Wt = np.unique(Wt.T, axis=0).T  

              Wt = stats.zscore(Wt, axis=0, ddof=1)
              T, N = Wt.shape[0], Wt.shape[1]

              BigTable = {} # COLUMNS: MSPE|hyper|kopt|mopt|popt|beta, ROWS: length of hypergrid
              for hypernum, hyper in enumerate(grid): 
                  # PCA
                  if Mode[0] == 'P':
                      pca = PCA(n_components=K)
                      Fhat = pca.fit_transform(Wt)
                  # SPC
                  if Mode[0] == 'S':
                      Wts = np.hstack((Wt, Wt**2))
                      Wts = StandardScaler().fit_transform(Wts)
                      pca = PCA(n_components=K)
                      Fhat = pca.fit_transform(Wts)
                  # KPCA
                  if Mode[0] == 'K':
                    if kernel == 'sigmoid' or kernel =='rbf':
                      transformer = KernelPCA(n_components=K, kernel = kernel, gamma=hyper) 
                    else:
                      transformer = KernelPCA(n_components=K, kernel=kernel, degree = 2) 
                    Fhat = transformer.fit_transform(Wt)

                  allpar = {}
                  BIC = np.zeros([K, M, P])
                  sigma2 = np.zeros([K, M, P])
                  sigma2.fill(np.NaN)
                  for pp in range(P):
                      [X, Xlag] = lagaugment(Ydt[:-hor], pp + 1)  
                      X = np.hstack((X[:, 0].reshape(X.shape[0], 1), Xlag[:, 0:-1]))
                      X = X[kill:, :]  

                      for kk in range(K):
                          Fhs = Fhat[:, :kk + 1] 

                          for mm in range(M):
                              [FhsL, FhsLag] = lagaugment(Fhs[:-hor], mm + 1) 
                              FhsL = np.hstack((FhsL.reshape(FhsL.shape[0], kk + 1), FhsLag[:, 0:-(kk + 1)]))  
                              if Mode == 'PC2':
                                FhsL = np.hstack((FhsL, FhsL**2))  

                              XF = np.hstack((np.ones([FhsL.shape[0]]).reshape(FhsL.shape[0], 1), np.hstack((X, FhsL))))  
                              YXF = np.hstack((Ygt[hor + kill:], XF))  
                              YXF = YXF[~np.any(np.isnan(YXF), axis=1), :]  

                              beta = np.dot(np.linalg.inv(np.dot(YXF[:, 1:].T, YXF[:, 1:])), np.dot(YXF[:, 1:].T, YXF[:, 0]))  

                              allpar[kk, mm, pp] = beta

                              vnum = XF.shape[1]
                              tnum = YXF.shape[0]

                              if tnum <= vnum:  # Handling rare degenerate cases -- making sure very bad BICs are ignored
                                  BIC[kk, mm, pp] = 0
                              else:
                                  yin = np.dot(YXF[:, 1:], beta)
                                  res = YXF[:, 0] - yin           
                                  sigma2 = np.dot(res.T, res) / (tnum - vnum)

                                  BIC[kk, mm, pp] = np.log(sigma2) + (vnum) * np.log(tnum) / tnum 
                              
                  [kopt, mopt, popt] = [np.where(BIC == np.min(BIC))[0][0] + 1, np.where(BIC == np.min(BIC))[1][0] + 1, np.where(BIC == np.min(BIC))[2][0] + 1]
                  beta = allpar[kopt - 1, mopt - 1, popt - 1]      

                  ct=5
                  [X, Xlag] = lagaugment(Ydt, popt)  
                  X = np.hstack((X[:, 0].reshape(X.shape[0], 1), Xlag[:, 0:-1]))
                  X = X[kill:, :]

                  [FhsL, FhsLag] = lagaugment(Fhat[:,:kopt], mopt) 
                  FhsL = np.hstack((FhsL.reshape(FhsL.shape[0], kopt), FhsLag[:, 0:-kopt]))
                  if Mode == 'PC2':
                    FhsL = np.hstack((FhsL, FhsL**2))  

                  XF = np.hstack((np.ones([FhsL.shape[0]]).reshape(FhsL.shape[0], 1), np.hstack((X, FhsL)))) 
                  YXF = XF[~np.any(np.isnan(XF), axis=1), :] 

                  yin = np.dot(YXF, beta)  
                  res = Yg[t:est_window + 1 + t][-ct-hor+1:Yg[t:est_window + 1 + t].shape[0]-int(hor/3)-1]  - yin[-ct-hor+1:yin.shape[0]-int(hor/3)-1].reshape(-1,1)  # Res 2:120, validate on last ct observations
                  MSPE = np.dot(res.T, res)
                  
                  # FOR EACH hyper record what was the best MSE|kopt|mopt|popt|beta
                  BigTable[hyper, kopt, mopt, popt, str(beta.tolist())] = MSPE
              
              hyper, kopt, mopt, popt, beta = min(BigTable, key=BigTable.get) # Retrieve parameters associated with *lowest MSPE* accross different hypers
              beta = eval(beta)
              
              if Mode[0] == 'K':
                if kernel == 'sigmoid' or kernel =='rbf':
                  transformer = KernelPCA(n_components=K, kernel = kernel, gamma=hyper) 
                else:
                  transformer = KernelPCA(n_components=K, kernel = kernel, degree = 2) 
                Fhat = transformer.fit_transform(Wt)

              # PREDICTION PRT
              [y, ylag] = lagaugment(Ydt, popt)
              y = np.hstack((y[:, 0].reshape(y.shape[0], 1), ylag[:, 0:-1]))
              y = y[-1, :]

              [FhOpt, FhOptlag] = lagaugment(Fhat[:, :kopt], mopt)
              FhOpt = np.hstack((FhOpt, FhOptlag[:, 0:-kopt]))
              if Mode == 'PC2':
                FhOpt = np.hstack((FhOpt, FhOpt**2))  # PC2 step!
              FhOpt = FhOpt[-1, :]

              lastx = np.hstack((1, np.hstack((y, FhOpt))))
              Yhat[t] = np.dot(lastx, beta)

          # For each variable, for each horizon:
          print("Variable:", varind, "Mode:", Mode, "Horizon:", hor)
          DMdic[Mode][:,varnum*len(horstotal) + hornum] = Ytrue.reshape(OOS_obs,) - Yhat.reshape(OOS_obs,)
          MSPE = np.mean((Ytrue - Yhat)**2)
          MSPEs[varnum, hornum] = MSPE
  if Mode[0] == 'P' or Mode[0] == 'S':
    np.savetxt('Data_Out/' + Mode + '_MSPEs.csv', MSPEs, delimiter=',')
  elif Mode[0] == 'K':
    np.savetxt('Data_Out/' + Mode + '_MSPEs.csv', MSPEs, delimiter=',')  

''' Prepare the final table'''
PCA_MSPEs = pd.read_csv('Data_Out/PCA_MSPEs.csv', header=None)
SPC_MSPEs = pd.read_csv('Data_Out/SPC_MSPEs.csv', header=None)
PC2_MSPEs = pd.read_csv('Data_Out/PC2_MSPEs.csv', header=None)
KPCApoly_MSPEs = pd.read_csv('Data_Out/KPCApoly_MSPEs.csv', header=None)
KPCAsigmoid_MSPEs = pd.read_csv('Data_Out/KPCAsigmoid_MSPEs.csv', header=None)
KPCArbf_MSPEs = pd.read_csv('Data_Out/KPCArbf_MSPEs.csv', header=None)

SPC_MSPEs = SPC_MSPEs/PCA_MSPEs
PC2_MSPEs = PC2_MSPEs/PCA_MSPEs
KPCApoly_MSPEs = KPCApoly_MSPEs/PCA_MSPEs
KPCAsigmoid_MSPEs = KPCAsigmoid_MSPEs/PCA_MSPEs
KPCArbf_MSPEs = KPCArbf_MSPEs/PCA_MSPEs

Merged = pd.concat([SPC_MSPEs, PC2_MSPEs, KPCApoly_MSPEs, KPCAsigmoid_MSPEs, KPCArbf_MSPEs])

Final_table = Merged.copy()
l=0
for j in range(SPC_MSPEs.shape[0]):
  for i in range(5):
    Final_table.iloc[l:l+1] = Merged.iloc[j+len(Series)*i:j+len(Series)*i+1].values
    l+=1

Final_table.columns = ["h=1", "h=3", "h=6", "h=9", "h=12", "h=18", "h=24"]
rownames = []
for i in range(SPC_MSPEs.shape[0]):
  rownames.append(['SPC', 'PC2', 'kPCA poly(2)', 'kPCA sigmoid', 'kPCA RBF'])
rownames = (lambda x: [item for sublist in x for item in sublist])(rownames)
Final_table.index = rownames
Final_table = np.round(Final_table,4)
np.savetxt('Data_Out/Final_table.csv', Final_table, delimiter=',')  

Latex = []
for inum,iseries in enumerate(Series):
  Latex.append('\multicolumn{8}{c}{'+Series[inum]+' series}\\\ \n\cmidrule(r){1-8}\n'+Final_table.iloc[inum*5:(inum+1)*5].to_latex()[120:-27]+'\n\cmidrule(r){1-8}\n')
Latex = "".join(Latex)
Latex = Latex.replace("PC2","PC$^2$")
Latex = Latex.replace("S&P","S\&P")
print(Latex)

# Diebold-Mariano
DMvalues = np.zeros([Merged.shape[0], Merged.shape[1]])
for i in range(len(indexes)):     # variable
  for modenum,mode in enumerate(['SPC','PC2','KPCApoly', 'KPCAsigmoid','KPCArbf']):  # No PCA, since comparing against it
    for hornum, hor in enumerate(horstotal): # horizon
      DMvalues[i*5+modenum,hornum] = dmtest(DMdic[mode][:,i*len(horstotal)+hornum], DMdic['PCA'][:,i*len(horstotal)+hornum], hor)

np.savetxt('Data_Out/DMvalues.csv', DMvalues, delimiter=',')  
